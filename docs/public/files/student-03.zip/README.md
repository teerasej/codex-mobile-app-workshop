# Service Desk Lite — Student 03

ไฟล์ส่วนตัวสำหรับการฝึกเท่านั้น ห้าม commit หรือส่งเข้า AI chat

## Microsoft Entra sign-in

เปิด https://portal.azure.com ลงชื่อเข้าใช้ sdl26111003@teerasejoutlook.onmicrosoft.com และเลือก Temporary Access Pass
TAP: -58=@=SZ
หมดอายุ (UTC): 2026-11-20T11:45:19.746294+00:00
บัญชีนี้ไม่ใช่บัญชี ChatGPT หรือ GitHub

## Day 2

คัดลอก api/.env ไปยังโปรเจคของตน ตรวจว่า .gitignore มี .env
Database: servicedesk_f093cbb8_03
Hostname: sdl-f093cbb8-pg.postgres.database.azure.com
Setup login: sdl_f093cbb8_setup_03
Setup password: bgqJxtBBQlNFnY_iAqepkz5xY4OAUdKtqamMvLjh!aA9
Runtime login: sdl_f093cbb8_api_03
ใช้ setup login เฉพาะการเตรียม schema/seed; API ใช้ runtime login

App user learner01: BH6QL3ouL4GWpReCQF43XrQO3ox0J4QIb_hT0Zyg!aA9
App user learner02: c26Bef1uy7jv0d3O9Hp59JxY2vlWYW_aqOauDKd2!aA9

## Day 4

Subscription: 2e1850a8-07a6-43c1-874b-16c5fcc2e165
Resource group: /subscriptions/2e1850a8-07a6-43c1-874b-16c5fcc2e165/resourceGroups/rg-sdl-f093cbb8-student03
API URL: Not deployed — สร้างระหว่างแบบฝึกหัด

เก็บ DATABASE_URL และ JWT_SECRET ไว้ฝั่ง API เท่านั้น Flutter ใช้ API_BASE_URL
Revision: 1.1
Exported: 2026-11-10T11:46:08.907Z
