# Service Desk Lite — Student 02

ไฟล์ส่วนตัวสำหรับการฝึกเท่านั้น ห้าม commit หรือส่งเข้า AI chat

## Microsoft Entra sign-in

เปิด https://portal.azure.com ลงชื่อเข้าใช้ sdl26111002@teerasejoutlook.onmicrosoft.com และเลือก Temporary Access Pass
TAP: naRk6JPB
หมดอายุ (UTC): 2026-11-20T11:44:57.735301+00:00
บัญชีนี้ไม่ใช่บัญชี ChatGPT หรือ GitHub

## Day 2

คัดลอก api/.env ไปยังโปรเจคของตน ตรวจว่า .gitignore มี .env
Database: servicedesk_f093cbb8_02
Hostname: sdl-f093cbb8-pg.postgres.database.azure.com
Setup login: sdl_f093cbb8_setup_02
Setup password: rAogjhMpmNf_bY6SonHqhhgmljRH_iG7OctTMFRu!aA9
Runtime login: sdl_f093cbb8_api_02
ใช้ setup login เฉพาะการเตรียม schema/seed; API ใช้ runtime login

App user learner01: Sks9JAxgDDgg5NA1q2HinhIiU47Hjx4zqpgp3WM1!aA9
App user learner02: OwrZH0v21OHNrYQiqZ3RAM_VAuVWNcKAH5E4geof!aA9

## Day 4

Subscription: 2e1850a8-07a6-43c1-874b-16c5fcc2e165
Resource group: /subscriptions/2e1850a8-07a6-43c1-874b-16c5fcc2e165/resourceGroups/rg-sdl-f093cbb8-student02
API URL: Not deployed — สร้างระหว่างแบบฝึกหัด

เก็บ DATABASE_URL และ JWT_SECRET ไว้ฝั่ง API เท่านั้น Flutter ใช้ API_BASE_URL
Revision: 1.1
Exported: 2026-11-10T11:46:08.907Z
