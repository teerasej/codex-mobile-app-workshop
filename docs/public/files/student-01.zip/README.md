# Service Desk Lite — Student 01

ไฟล์ส่วนตัวสำหรับการฝึกเท่านั้น ห้าม commit หรือส่งเข้า AI chat

## Microsoft Entra sign-in

เปิด https://portal.azure.com ลงชื่อเข้าใช้ sdl26111001@teerasejoutlook.onmicrosoft.com และเลือก Temporary Access Pass
TAP: C8$xGS-X
หมดอายุ (UTC): 2026-11-20T11:44:35.837520+00:00
บัญชีนี้ไม่ใช่บัญชี ChatGPT หรือ GitHub

## Day 2

คัดลอก api/.env ไปยังโปรเจคของตน ตรวจว่า .gitignore มี .env
Database: servicedesk_f093cbb8_01
Hostname: sdl-f093cbb8-pg.postgres.database.azure.com
Setup login: sdl_f093cbb8_setup_01
Setup password: 3-eLmo9MAQkXxczh5tduIo-wwxx1WeG85ZtAI3MP!aA9
Runtime login: sdl_f093cbb8_api_01
ใช้ setup login เฉพาะการเตรียม schema/seed; API ใช้ runtime login

App user learner01: lNZMFFioOFwOByaaxXo2OYN5uVTdDL5ywq6LOEOv!aA9
App user learner02: GqiAMDy9wfgH5MrHeuGfiCLs1SfyivT5ednd6kId!aA9

## Day 4

Subscription: 2e1850a8-07a6-43c1-874b-16c5fcc2e165
Resource group: /subscriptions/2e1850a8-07a6-43c1-874b-16c5fcc2e165/resourceGroups/rg-sdl-f093cbb8-student01
API URL: Not deployed — สร้างระหว่างแบบฝึกหัด

เก็บ DATABASE_URL และ JWT_SECRET ไว้ฝั่ง API เท่านั้น Flutter ใช้ API_BASE_URL
Revision: 1.1
Exported: 2026-11-10T11:46:08.907Z
